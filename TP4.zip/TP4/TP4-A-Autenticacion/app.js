import {config} from './dbconfig.js'
import express from "express";
import 'dotenv/config';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

import pkg from 'pg'
const {Client} = pkg;

const app = express()
const PORT = 8000
app.use(express.json());

app.post('/crearusuario', async (req, res) => {
  const user = req.body; 
  console.log("User data:", user);

  if (!user.nombre || !user.id || !user.password) {
    return res.status(400).json({ message: "Debe completar todos los campos" });
  }

  try {
    const client = new Client(config);
    await client.connect();

    // encriptar la contraseña
    const hashedPassword = await bcrypt.hash(user.password, 10);
    user.password = hashedPassword;
  
    console.log("insertando usuario:", user);
    // insertar en la base de datos
    const result = await client.query(
      "INSERT INTO usuario ( nombre, password) VALUES ( $1, $2) RETURNING *",
      [user.nombre, user.password]
    );

    await client.end();

    console.log("Rows creadas:", result.rowCount);
    res.send(result.rows);

  } catch (error) {
    console.error("Error al registrar usuario:", error);
    return res.status(500).json({ message: error.message });
  }
});

app.post('/login', async (req, res) => {
  const user = req.body;
  console.log("User data:", user);

  if (!user.id || !user.password) {
    return res.status(400).json({ message: "Debe completar todos los campos" });
  }

  try {
    const client = new Client(config);
    await client.connect();

    const result = await client.query(
      "SELECT * FROM usuario WHERE id=$1",
      [user.id]
    );

    await client.end();

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    const dbUser = result.rows[0];

    // comparar contraseña ingresada con la encriptada en BD
    const passOK = await bcrypt.compare(user.password, dbUser.password);

    if (!passOK) {
      return res.status(401).json({ message: "Clave inválida" });
    }

    // generar token JWT usando opciones personalizadas
    const payload = {
      usuarioID: dbUser.id,
      nombre: dbUser.nombre
    };

    console.log("Payload del token:", payload);
    const secretKey = 'contraseña';
    const options = {
      expiresIn: '1h',
    };

    const token = jwt.sign(payload, secretKey, options);

    res.json({ token });

  } catch (error) {
    console.error("Error en login:", error);
    return res.status(500).json({ message: error.message });
  }
});

app.get('/escucho', async (req, res) => {
  const { Token } = req.query;

  if (!Token) {
    return res.status(400).json({ message: "Token requerido" });
  }

  try {
    // verifica token
    const decoded = jwt.verify(Token, 'contraseña');
    const usuarioID = decoded.usuarioID;

    const client = new Client(config);
    await client.connect();

    console.log("Usuario ID desde token:", decoded);
    console.log("Token", Token);
    // obtiene las canciones escuchadas y la cantidad de reproducciones
    const result = await client.query(
      `SELECT c.nombre AS cancion, SUM(e.reproducciones) AS total_reproducciones
       FROM escucha e
       JOIN cancion c ON e.cancionid = c.id
       WHERE e.usuarioid = $1
       GROUP BY c.nombre
       ORDER BY total_reproducciones DESC`,
      [usuarioID]
    );

    await client.end();

    res.json(result.rows);
  } catch (error) {
    console.error("Error al obtener canciones escuchadas:", error);
    return res.status(401).json({ message: "Token inválido o expirado" });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server is running on port ${PORT}`);
})